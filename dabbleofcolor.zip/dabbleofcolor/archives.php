<?php

	/*

	Template Name: Archive

	*/

	?>

	<?php get_header(); ?>

	    <div id="content">

	        <div id="content-left" style="padding-top: 20px;">

	                 

	                <div class="post">   

	                    <h1><?php the_title(); ?></h1>

	                         

	                    <ul>

	                        <?php wp_get_archives('type=monthly'); ?>

	                    </ul>

	                </div>

	      </div><!-- end content-left -->

	      <?php get_sidebar(); ?>

	      <div class="clear"></div>

	</div><!-- end content -->
	<?php get_footer(); ?>