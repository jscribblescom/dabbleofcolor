<?php get_header(); ?>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		

<p class="clear"></p>

	<div class="post" id="post-<?php the_ID(); ?>">


 <div class="post-title"> <?php the_title(); ?> </div> 
             		
			<?php the_content(); ?>

			



					

			

<a name="comments"></a>

<?php comments_template(); ?>

<?php endwhile; else: ?>
		<h1>Not Found</h1>
		<p>Sorry, but the page you requested cannot be found. If you feel this is an error, let me know.</p>
<?php endif; ?>

<?php get_footer(); ?>