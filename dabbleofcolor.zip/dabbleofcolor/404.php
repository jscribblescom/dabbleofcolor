<?php get_header(); ?>

 
	 
	    <center><b>WARNING! The page you are looking for no longer exists.</b></center>
	 
	    <p>This error may be troublesome to most, but don't fret, it can be fixed within a click of your browser's back-button. You can also try the Navigation located to your right -->.</p>

           <p>If you feel that you have reached this page in <b>ERROR</b>, either by my doing, or by yours...please feel free to email me <a href="mailto:ladyjay050@gmail.com">ladyjay050@gmail.com</a>. And I will try to fix this mistake.</p>

           <p>If for whatever reason, you feel that this page <i>SHOULD</i> exist, I urge you to notify me at once. Otherwise, I will just think
that you're trying to peep!</p>
	 
	    <ul>
	        <li>You can search our site using the form provided below.</li>
	 <form role="search" method="get" id="searchform" class="searchform" action="<?php esc_url( home_url( '/' )); ?>">
	<div>
		<label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
		<input type="text" value="<?php get_search_query(); ?>" name="s" id="s" />
		<input type="submit" id="searchsubmit" value="<?php esc_attr_x( 'Search', 'submit button' ); ?>" />
	
</form>
	  
	<?php get_footer(); ?>