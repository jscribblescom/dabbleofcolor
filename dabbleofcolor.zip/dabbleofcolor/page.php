<?php
/**
 * @package WordPress
 * @subpackage Classic_Theme
 */
get_header();
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2><div class="post-title"> <?php the_title(); ?></div></h2>

	<div class="storycontent">
		<?php the_content(__('(more...)')); ?>
	</div>


	



<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>


<?php get_footer(); ?>
