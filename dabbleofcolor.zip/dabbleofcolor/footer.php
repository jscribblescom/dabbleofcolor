<div class="older-entries"><?php next_posts_link( '« Older Entries' ); ?></div>

<div class="newer-entries"><?php previous_posts_link( 'Newer Entries » ' ); ?></div><br/><br/>
<br/>
<div id="footer2">
	<div id="footer-1">
	<p class="centered">
		<h1>
		Hi there, I'm Jamie!
		</h1>
I am a creative thinker who has a passion for anything web design. I'm also a hobbyist web developer, student, and artist. I love to listen to music, write, read, and create sites. Check out my <a href="http://jbytes.us" target="_blank">Personal Homepage</a>. 
</div>
	
	<div id="footer-2">
		<p class="centered">
			
			<h1>
				Apostrophes!
		</h1>
		Apostrophes.us is a blog that shares my thoughts on being a college student, a web designer, my writings, and my experiences of life in general. If you'd like, check out the blog's <a href="http://apostrophes.us/feed" target="_blank">RSS FEED</a>. 
		
		
	</div>


<div id="footer-3">
<p class="centered">
		
	

<h1>
	Let's Get Social!
	</h1>
	
	
	If you have any of the following social media accounts, please don't hesitate to follow me.<br/>
	
	<div class="fa">
	<p class="centered">
		<a href="https://www.facebook.com/hotpatootieblessmysoul" class="fa fa-facebook" aria-hidden="true" target="_blank"></a>
	<a href="https://www.twitter.com/_jbytes" class="fa fa-twitter" aria-hidden="true" target="_blank"></a>
		<a href="https://www.instagram.com/omgitisjamie" class="fa fa-instagram" aria-hidden="true" target="_blank"></a>
		<a href="http://apostrophes.us/feed" class="fa fa-rss" aria-hidden="true" target="_blank"></a></p>
</div>
	

 
</div>
<br/>


<div id="footer">
<p class="centered">
Copyright &copy; 2017-2018 <a href="http://jbytes.us" target="_blank">Jamie</a>

	&bull; Hosted by: <a href="http://www.candyrain.org" target="_blank">Candyrain.org</a> &bull; All rights reserved. <a href="#">&#x21E1; To Top</a></p></div>

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script>
		$("#main-menu--toggle").click(function(){
			$("#main-menu--expanded").slideToggle("slow");
		});
	</script>


 

</body>
</html>  