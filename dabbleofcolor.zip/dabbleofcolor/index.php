<?php
/**
 * @package WordPress
 * @subpackage Classic_Theme
 */
get_header();
?>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
<div class="post-title"> <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute( array( 'before' => 'Permalink to: ', 'after' => '' ) ); ?>"><?php the_title(); ?></a></div><br/>
	
<div class="categories">
Posted on: <?php the_date(' F j, Y'); ?> &bull;  Filed Under: <?php the_category(', '); ?> &bull;  With: <?php comments_popup_link(__('0 Comments'), __('1 Comment'), __('% Comments'));?> </div> 


		
<div class="post-content">
 

	<div class="storycontent">
	
		<?php the_content('<div class="read-more-link">Continue Reading &raquo;</div>'); ?>		


		
	
				


</div>
</div>


<?php comments_template(); // Get wp-comments.php template ?>
<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<?php get_footer(); ?>

